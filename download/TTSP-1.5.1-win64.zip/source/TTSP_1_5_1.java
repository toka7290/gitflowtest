import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.video.*; 
import processing.sound.*; 
import java.util.Arrays; 
import java.time.LocalDateTime; 
import java.time.ZoneId; 
import java.time.ZonedDateTime; 
import java.time.format.DateTimeFormatter; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class TTSP_1_5_1 extends PApplet {









//定数
final int max = 30;//親
final int cMax = 20;//子
final int gMax = 10;//孫
final String ftmovie = "movie",
             ftpict = "image", 
             ftpro = "program",
             fthide = "hide";//filetype

/*基本*/
Movie[] mov = new Movie[max];//動画
PImage[] image = new PImage[max];
boolean[] isloop = new boolean[max];//動画がループするかどうか
PImage[] sec = new PImage[max];//画像
String[] name = new String[max];//ファイル名
String[] mode = new String[max];//モード切替
String[] ratio= new String[max];//比
String[] ftback = new String[max];//filetype
int[] BGRGB = new int[max];//背景色
float[] time = new float[max];//シーン有効時間
         
/*外部参照関連*/
XML program;//program.xml管理
XML[] config = new XML[max];//シーン管理
XML XMback, XMsec, XMmin, XMhour;//clock用
JSONObject Settings;//設定管理
String mediadirectory;
String fontdirectory;

/*制御関連*/
PVector centerPos;//中心座標
PVector imageSize;//表示中の画像サイズ
PVector[][] anyPos = new PVector[max][cMax];//任意座標
int dsate = 0;//draw_sate面切り替え
int check = 0;//面切り替えチェック
float passage;//シーン開始時間
float timer;//タイマー
boolean ready = false;//準備完了
int debug_screen = 0;
String nowload;//読み込み中のシーン
String allscenevaule;//シーン合計

/*clock*/
XML clock;
XML[] object = new XML[cMax];
XML[] moveClock = new XML[gMax];
String[][] clockFont = new String[max][cMax];
int[] numOfClock = new int[max];
int[][] fontColor = new int[max][cMax];
String[][] clockType = new String[max][cMax];
PVector[][] clockPos = new PVector[max][cMax];
PVector[][] stCloPos = new PVector[max][cMax];
/*analog*/
XML xmlSec, xmlMin, xmlHour, xmlboard;
PImage[][] boardImg = new PImage[max][cMax];
PImage[][] secImg = new PImage[max][cMax];
PImage[][] minImg = new PImage[max][cMax];
PImage[][] hourImg = new PImage[max][cMax];
PVector[][] secAxis = new PVector[max][cMax];
PVector[][] minAxis = new PVector[max][cMax];
PVector[][] hourAxis = new PVector[max][cMax];
PVector dialPos = new PVector(0,0);
PVector dialPos2 = new PVector(0,0);
PVector dialPos3 = new PVector(0,0);
int[][] dialColor = new int[max][cMax];
int[][] indexColor = new int[max][cMax];
int[][] secColor = new int[max][cMax];
int[][] minColor = new int[max][cMax];
int[][] hourColor = new int[max][cMax];
int[][] secWidth = new int[max][cMax];//秒針長さ
int[][] minWidth = new int[max][cMax];//長針長さ
int[][] hourWidth = new int[max][cMax];//短針長さ
int[][] indexwidth = new int[max][cMax];//盤面太さ
float secHandsize = 1.0f;
float minHandsize = 1.0f;
float hourHandsize = 1.0f;
float indexOut = 1.0f;
float indexIn = 1.0f;
float indexIn_2 = 1.0f;
float dialsize = 1.0f;
float s = 0;//秒角度
float s_sm = 0;
float m = 0;//分角度
float m_sm = 0;
float h = 0;//時角度
float h_sm = 0;
float[][] secondsRadius = new float[max][cMax];//秒針長さ
float[][] minutesRadius = new float[max][cMax];//長針長さ
float[][] hoursRadius = new float[max][cMax];//短針長さ
float[][] clockDiameter = new float[max][cMax];//時計円サイズ
float[][] dialRadius = new float[max][cMax];
float[][] dialRadius2 = new float[max][cMax];
float[][] dialRadius3 = new float[max][cMax];//盤表示用
float[][] clockSize = new float[max][cMax];//基準サイズ
boolean[][] secSmooth = new boolean[max][cMax];
boolean[][] minSmooth = new boolean[max][cMax];
boolean[][] hourSmooth = new boolean[max][cMax];//滑らかな針
ZoneId[][] zone = new ZoneId[max][cMax];//タイムゾーン
DateTimeFormatter[][] datetimeformat = new DateTimeFormatter[max][cMax];//表示形式

/*pulsモード*/
PImage[][] backPlus = new PImage[max][max];//to画像
XML plus;//+用
XML[] display = new XML[cMax];//フェード用
XML[] move = new XML[gMax];//+用移動管理
int[] fade = new int[max];//切替面数
float[] transparency = new float[max];//透明度
float[][] timing = new float[max][cMax];//フェード開始時間
float[][] duration = new float[max][cMax];//フェード時間
String[][] ratioPlus= new String[max][cMax];//to比
String[][] ftbackPlus = new String[max][cMax];//tofiletype
/*moving用関数*/
PVector[][][] moveBegin = new PVector[max][cMax][gMax];//初期座標
PVector[][][] moveEnd = new PVector[max][cMax][gMax];//最後座標
PVector[][][] moveDist = new PVector[max][cMax][gMax];//差分座標
float[][][] moveStart = new float[max][cMax][gMax];//開始時間
float[][][] moveDuration = new float[max][cMax][gMax];//継続時間
String[][][] moveBehavior = new String[max][cMax][gMax];//移動挙動
float[][][] percent = new float[max][cMax][gMax];//進捗
boolean[][][] isMoving = new boolean[max][cMax][gMax];//動くかどうか
boolean[][][] movingEnd = new boolean[max][cMax][gMax];//移動終了
int msate = 0;//moving_sate
boolean firstD = true;

public void settings(){
  Settings = loadJSONObject("Settings.json");
  program = loadXML(Settings.getString("useProgram_xml"));
  config = program.getChildren("config");
  if(Settings.getInt("Wideth") >= 1 && Settings.getInt("height") >= 1){
    size(Settings.getInt("Wideth"), Settings.getInt("height"));
  }else 
  if(Settings.getInt("Wideth") >= 1 && Settings.getInt("height") == -1){
    size(Settings.getInt("Wideth"), displayHeight);
  }else 
  if(Settings.getInt("Wideth") == -1 && Settings.getInt("height") >= 1){
    size(displayWidth, Settings.getInt("height"));
  }else 
  if(Settings.getInt("Wideth") == -1 && Settings.getInt("height") == -1){
    fullScreen(Settings.getInt("fullscreenTo"));
  }else{
    size(300, 100);
    print("error01-Size is not specified");
  }
  mediadirectory = Settings.getString("mediadirectory");
  fontdirectory = Settings.getString("fontdirectory");
  secHandsize = Settings.getFloat("secHandsize");
  minHandsize = Settings.getFloat("minHandsize");
  hourHandsize = Settings.getFloat("hourHandsize");
  indexOut = Settings.getFloat("indexOut");
  indexIn = Settings.getFloat("indexIn");
  indexIn_2 = Settings.getFloat("indexIn_2");
  dialsize = Settings.getFloat("dialsize");
}

public void setup(){
  frameRate(240);
  background(0);
  centerPos = new PVector(width / 2, height / 2);
  imageSize = new PVector(width, height);
  textAlign(CENTER, CENTER);
  imageMode(CENTER);
  loading();
  //thread("loading");
  for(int i = 0; i < max; i++){
    transparency[i] = 255;
    for(int o = 0; o < cMax; o++){
      anyPos[i][o] = centerPos.copy();
    }
  }
  print("start \n-elapsed time "+millis()+" [ms]\n");
}

public void draw(){
  if(!ready){
    clear();
    fill(255);
    textFont(createFont("/font/meiryo.ttc",height*0.05f));
    text("please start any key\n"+allscenevaule+"\n"+nowload, width/2,height*3/4);
    passage = millis();
  }else{
    run_draw();
  }
}

public void keyTyped() {
  ready = true;
}
public void run_draw(){
  if(dsate != check){//画面切り替え時に動作
    passage = millis();//起動時からの経過秒
    if(dsate >= config.length){
      dsate = 0;
    }
    check = dsate;
    msate = 0;
    firstD = true;
    centerPos.set(width / 2, height / 2);
    for(int i = 0; i < max; i++){
      transparency[i] = 255;
      for(int o = 0; o < cMax; o++){
        anyPos[i][o] = centerPos.copy();
        for(int p = 0; p < gMax; p++){
          movingEnd[i][o][p] = false;
        }
      }
    }
  }
  timer = (millis() - passage)/1000;
  
  clear();
  noStroke();
  background(BGRGB[dsate]);
  
  switch(mode[dsate]){
    case "normal+":
      for(int i = fade[dsate]; i >= 0; i--){
        if(isMoving[dsate][i][msate] &&
          moveStart[dsate][i][msate] <= timer){//isMovingがtrueの時時間になったら開始
          if(!movingEnd[dsate][i][msate]){//最後まで来ていなければ
            percent[dsate][i][msate] = map(timer, moveStart[dsate][i][msate], moveStart[dsate][i][msate] + moveDuration[dsate][i][msate], 0, 1);
            switch(moveBehavior[dsate][i][msate]){
              case "accel"://加速
                anyPos[dsate][i].x = moveBegin[dsate][i][msate].x + (percent[dsate][i][msate] * moveDist[dsate][i][msate].x);//a*x
                anyPos[dsate][i].y = moveBegin[dsate][i][msate].y + (percent[dsate][i][msate] * moveDist[dsate][i][msate].y);
                break;
              case "accel_2"://累乗加速
                anyPos[dsate][i].x = moveBegin[dsate][i][msate].x + (pow(percent[dsate][i][msate], 4) * moveDist[dsate][i][msate].x);//(a^4)*x
                anyPos[dsate][i].y = moveBegin[dsate][i][msate].y + (pow(percent[dsate][i][msate], 4) * moveDist[dsate][i][msate].y);
                break;
              case "accel_3"://円加速
                anyPos[dsate][i].x = moveBegin[dsate][i][msate].x + (sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * moveDist[dsate][i][msate].x);//sin(a)*x
                anyPos[dsate][i].y = moveBegin[dsate][i][msate].y + (sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * moveDist[dsate][i][msate].y);
                break;
              case "decel"://減速
                anyPos[dsate][i].x += percent[dsate][i][msate] * (moveEnd[dsate][i][msate].x - anyPos[dsate][i].x);//a*(xe-x)
                anyPos[dsate][i].y += percent[dsate][i][msate] * (moveEnd[dsate][i][msate].y - anyPos[dsate][i].y);
                break;
              case "decel_2"://累乗減速
                anyPos[dsate][i].x += pow(percent[dsate][i][msate], 4) * (moveEnd[dsate][i][msate].x - anyPos[dsate][i].x);//(a^4)*(xe-x)
                anyPos[dsate][i].y += pow(percent[dsate][i][msate], 4) * (moveEnd[dsate][i][msate].y - anyPos[dsate][i].y);
                break;
              case "decel_3"://円減速
                anyPos[dsate][i].x += sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * (moveEnd[dsate][i][msate].x - anyPos[dsate][i].x);//sin(a)*(xe-x)
                anyPos[dsate][i].y += sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * (moveEnd[dsate][i][msate].y - anyPos[dsate][i].y);
                break;
              case "warp"://ワープ
                anyPos[dsate][i].x = moveEnd[dsate][i][msate].x;
                anyPos[dsate][i].y = moveEnd[dsate][i][msate].y;
                break;
            }
            if(moveStart[dsate][i][msate] + moveDuration[dsate][i][msate] < timer){//最後に来た場合
              movingEnd[dsate][i][msate] = true;
              msate++;
            }
          }
        }
        if(i <= 0){//最初
        }else{//二面目から
          switch(ftbackPlus[dsate][i]){
            case ftpict:
              if(timer >= time[dsate]){
                dsate++;
                return;
              }else{
                imageDraw(backPlus[dsate][i], ratioPlus[dsate][i], min(width, height), anyPos[dsate][i]);
              }
              break;
            case fthide:
              break;
          }
          noTint();
          tint(255, transparency[i]);
          if(0 < transparency[i]){
            transparency[i] = map(timer, timing[dsate][i], timing[dsate][i]+duration[dsate][i], 255, 0);
            if(duration[dsate][i] == 0){
              duration[dsate][i] = 0;
            }
          }
        }
      }
    case "normal":
      main_drawing();
      break;
    case "debug":
      switch(debug_screen){
        default:
        case 0:
          float h_01 = height*0.6f;
          float h_02 = height*0.05f;
          float w_01 = width/8;
          /*一段目*/
          fill(255);
          rect(0, 0, w_01, h_01);
          fill(255, 255, 0);
          rect(w_01, 0, width/4, h_01);
          fill(0, 255, 255);
          rect(width/4, 0, (w_01)*3, h_01);
          fill(0, 255, 0);
          rect((w_01)*3, 0, width/2, h_01);
          fill(255, 0, 255);
          rect(width/2, 0, (w_01)*5, h_01);
          fill(255, 0, 0);
          rect((w_01)*5, 0, (w_01)*6, h_01);
          fill(0, 0, 255);
          rect((w_01)*6, 0, (w_01)*7, h_01);
          fill(128, 128, 128);
          rect((w_01)*7, 0, width, h_01);
          /*二段目*/
          fill(0, 0, 255);
          rect(0, h_01, w_01, h_02);
          fill(0);
          rect(w_01, h_01, width/4, h_02);
          fill(255, 0, 255);
          rect(width/4, h_01, (w_01)*3, h_02);
          fill(0);
          rect((w_01)*3, h_01, width/2, h_02);
          fill(0, 255, 255);
          rect(width/2, h_01, (w_01)*5, h_02);
          fill(0);
          rect((w_01)*5, h_01, (w_01)*6, h_02);
          fill(255);
          rect((w_01)*6, h_01, (w_01)*7, h_02);
          fill(0);
          rect((w_01)*7, h_01, width, height*0.05f);
          /*３段目*/
          fill(16, 0, 128);
          rect(0, height*0.65f, w_01, height*0.35f);
          fill(64, 0, 128);
          rect(width/4, height*0.65f, (w_01)*3, height*0.35f);
          setGradient((w_01)*3, height*0.65f, (w_01)*6, height*0.35f, 0, 255);
          break;
        case 1:
          stroke(0);
          line(0, 0, width, height);
          line(0, height, width, 0);
          line(0, height/2, width, height/2);
          line(width/2, 0, width/2, height);
          break;
        case 2:
          textFont(createFont("/font/MS-PGothic-100.vlw", height/4));
          fill(0);
          text("A 1 あ", width/2, height/2);
          break;
      }
      break;
    case "clock":
      main_drawing();
      for(int i = 0; i < numOfClock[dsate]; i++){
        if(firstD){//２週目以降対策
          clockPos[dsate][i] = stCloPos[dsate][i].copy();
          firstD = false;
        }
        if(isMoving[dsate][i][msate] &&
          moveStart[dsate][i][msate] <= timer){//isMovingがtrueの時時間になったら開始
          if(!movingEnd[dsate][i][msate]){//最後まで来ていなければ
            percent[dsate][i][msate] = map(timer, moveStart[dsate][i][msate], moveStart[dsate][i][msate] + moveDuration[dsate][i][msate], 0, 1);
            switch(moveBehavior[dsate][i][msate]){
              case "accel"://加速
                clockPos[dsate][i].x = moveBegin[dsate][i][msate].x + (percent[dsate][i][msate] * moveDist[dsate][i][msate].x);//a*x
                clockPos[dsate][i].y = moveBegin[dsate][i][msate].y + (percent[dsate][i][msate] * moveDist[dsate][i][msate].y);
                break;
              case "accel_2"://累乗加速
                clockPos[dsate][i].x = moveBegin[dsate][i][msate].x + (pow(percent[dsate][i][msate], 4) * moveDist[dsate][i][msate].x);//(a^4)*x
                clockPos[dsate][i].y = moveBegin[dsate][i][msate].y + (pow(percent[dsate][i][msate], 4) * moveDist[dsate][i][msate].y);
                break;
              case "accel_3"://円加速
                clockPos[dsate][i].x = moveBegin[dsate][i][msate].x + (sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * moveDist[dsate][i][msate].x);//sin(a)*y
                clockPos[dsate][i].y = moveBegin[dsate][i][msate].y + (sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * moveDist[dsate][i][msate].y);
                break;
              case "decel"://減速
                clockPos[dsate][i].x += percent[dsate][i][msate] * (moveEnd[dsate][i][msate].x - clockPos[dsate][i].x);//a*(xe-x)
                clockPos[dsate][i].y += percent[dsate][i][msate] * (moveEnd[dsate][i][msate].y - clockPos[dsate][i].y);
                break;
              case "decel_2"://累乗減速
                clockPos[dsate][i].x += pow(percent[dsate][i][msate], 4) * (moveEnd[dsate][i][msate].x - clockPos[dsate][i].x);//(a^4)*(xe-x)
                clockPos[dsate][i].y += pow(percent[dsate][i][msate], 4) * (moveEnd[dsate][i][msate].y - clockPos[dsate][i].y);
                break;
              case "decel_3"://円減速
                clockPos[dsate][i].x += sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * (moveEnd[dsate][i][msate].x - clockPos[dsate][i].x);//sin(a)*(xe-x)
                clockPos[dsate][i].y += sin(radians(map(percent[dsate][i][msate], 0, 1, 0, 90))) * (moveEnd[dsate][i][msate].y - clockPos[dsate][i].y);
                break;
              case "warp"://ワープ
                clockPos[dsate][i].x = moveEnd[dsate][i][msate].x;
                clockPos[dsate][i].y = moveEnd[dsate][i][msate].y;
                break;
            }
            if(moveStart[dsate][i][msate] + moveDuration[dsate][i][msate] < timer){//最後に来た場合
              movingEnd[dsate][i][msate] = true;
              msate++;
            }
          }
        }
        switch(clockType[dsate][i]){
          case "degital"://デジタル時計
            textFont(createFont(clockFont[dsate][i],clockSize[dsate][i]));
            //fill(159,199,128);
            //text("88:88",anyPos[dsate][i].x,anyPos[dsate][i].y);
            fill(fontColor[dsate][i]);
            text(datetimeformat[dsate][i].format(ZonedDateTime.now(zone[dsate][i])),
                  clockPos[dsate][i].x, clockPos[dsate][i].y);
            break;

          case "analog_img":
            boardImg[dsate][i].resize(0, PApplet.parseInt(clockDiameter[dsate][i]));
            image(boardImg[dsate][i], clockPos[dsate][i].x, clockPos[dsate][i].y);

            translate(clockPos[dsate][i].x, clockPos[dsate][i].y);//回転中心設定
            if(secSmooth[dsate][i])s = s_sm;
            if(minSmooth[dsate][i])m = m_sm;
            if(hourSmooth[dsate][i])h = h_sm;
            /*秒針部分*/
            rotate(s);
            secImg[dsate][i].resize(0, PApplet.parseInt(clockSize[dsate][i]));
            image(secImg[dsate][i], secAxis[dsate][i].x, secAxis[dsate][i].y);
            rotate(-s);
            /*長針部分*/
            rotate(m);
            minImg[dsate][i].resize(0, PApplet.parseInt(clockSize[dsate][i]));
            image(minImg[dsate][i], minAxis[dsate][i].x, minAxis[dsate][i].y);
            rotate(-m);
            /*短針部分*/
            rotate(h);
            hourImg[dsate][i].resize(0, PApplet.parseInt(clockSize[dsate][i]));
            image(hourImg[dsate][i], hourAxis[dsate][i].x, hourAxis[dsate][i].y);
            rotate(-h);
            translate(-clockPos[dsate][i].x, -clockPos[dsate][i].y);
            break;
          case "analog_pro":
            //円部分
            noStroke();
            fill(dialColor[dsate][i]);//次の円を塗りつぶす
            ellipse(clockPos[dsate][i].x, clockPos[dsate][i].y, clockDiameter[dsate][i], clockDiameter[dsate][i]);//円描画
            fill(255);//白
            ellipse(clockPos[dsate][i].x, clockPos[dsate][i].y, 10, 10);//中心点描画
            // 盤表示
            stroke(indexColor[dsate][i]);
            strokeWeight(indexwidth[dsate][i]);
            beginShape(LINES);
            for (int a = 0; a < 360; a+=6) {
              float angle = radians(a);
              dialPos.x = clockPos[dsate][i].x + cos(angle) * dialRadius[dsate][i];
              dialPos.y = clockPos[dsate][i].y + sin(angle) * dialRadius[dsate][i];
              dialPos2.x = clockPos[dsate][i].x + cos(angle) * dialRadius2[dsate][i];
              dialPos2.y = clockPos[dsate][i].y + sin(angle) * dialRadius2[dsate][i];
              dialPos3.x = clockPos[dsate][i].x + cos(angle) * dialRadius3[dsate][i];
              dialPos3.y = clockPos[dsate][i].y + sin(angle) * dialRadius3[dsate][i];
              vertex(dialPos.x, dialPos.y);
              if(a%5 == 0){
                strokeWeight(indexwidth[dsate][i]*1.5f);
                vertex(dialPos3.x, dialPos3.y);
              }
              else{
                strokeWeight(indexwidth[dsate][i]);
                vertex(dialPos2.x, dialPos2.y);
              }
            }
            if(secSmooth[dsate][i])s = s_sm;
            if(minSmooth[dsate][i])m = m_sm;
            if(hourSmooth[dsate][i])h = h_sm;
            stroke(secColor[dsate][i]);
            strokeWeight(secWidth[dsate][i]);
            line(clockPos[dsate][i].x, clockPos[dsate][i].y, clockPos[dsate][i].x + cos(s - HALF_PI) * secondsRadius[dsate][i], clockPos[dsate][i].y + sin(s - HALF_PI) * secondsRadius[dsate][i]);
            
            stroke(minColor[dsate][i]);
            strokeWeight(minWidth[dsate][i]);
            line(clockPos[dsate][i].x, clockPos[dsate][i].y, clockPos[dsate][i].x + cos(m - HALF_PI) * minutesRadius[dsate][i], clockPos[dsate][i].y + sin(m - HALF_PI) * minutesRadius[dsate][i]);

            stroke(hourColor[dsate][i]);
            strokeWeight(hourWidth[dsate][i]);
            line(clockPos[dsate][i].x, clockPos[dsate][i].y, clockPos[dsate][i].x + cos(h - HALF_PI) * hoursRadius[dsate][i], clockPos[dsate][i].y + sin(h - HALF_PI) * hoursRadius[dsate][i]);
            break;
        }
      clock_r(i);//針角度設定
      }
      break;
  }
  noTint();
}

public void movieEvent(Movie m) {
  m.read();
}
/*
void test(){
  if(mov[dsate].available()){
    mov[dsate].read();
  }
}*/

public void main_drawing(){
  switch(ftback[dsate]){
    case ftmovie:
      if(isloop[dsate]){//ループの場合
        mov[dsate].loop();
        imageDraw(mov[dsate], ratio[dsate], min(width, height), anyPos[dsate][0]);
      }else{
        if(mov[dsate].time() >= mov[dsate].duration() ||
            mov[dsate].time() >= time[dsate]){//終点まで来たら切替
          mov[dsate].stop();
          dsate++;
          return;
        }else{
          mov[dsate].play();
          imageDraw(mov[dsate],ratio[dsate], min(width, height), anyPos[dsate][0]);
        }
      }
      //thread("test");
      break;
    case ftpict:
      if(timer >= time[dsate]){
        dsate++;
        return;
      }else{
        imageDraw(image[dsate], ratio[dsate], min(width, height), anyPos[dsate][0]);
      }
      break;
    case fthide:
    default:
      if(timer >= time[dsate]){
        dsate++;
        return;
      }
      break;
  }
}

public void main_loading(int i){
  name[i] = config[i].getString("name");
  if(name[i].contains(".mp4") || name[i].contains(".mov")){//動画
    mov[i] = new Movie(this, mediadirectory+name[i]);
    ratio[i] = config[i].getString("ratio");
    ftback[i] = ftmovie;
    switch(config[i].getString("switching")){
      case "time":
        time[i] = config[i].getInt("time");
        break;
      case "end":
        time[i] = 2592000;
        break;
      case "loop":
        isloop[i] = true;
        break;
      default:
        time[i] = 0;
        print("warning01-Unknown setting value");
        break;
    }
  }else 
  if(name[i].contains(".png") || name[i].contains(".gif") || 
      name[i].contains(".jpg") || name[i].contains(".tga")){//画像
    time[i] = config[i].getInt("time");
    image[i] = loadImage(mediadirectory+name[i]);
    if(image[i] == null){
      image[i] = createImage(100,100,ALPHA);
    }
    ratio[i] = config[i].getString("ratio");
    ftback[i] = ftpict;
  }
  else if(name[i].contains("hide") || name[i].contains("void")){//表示しない 
    time[i] = config[i].getInt("time");
    ftback[i] = fthide;
  }
}

public boolean isNumber(String num) {
  try {
      Integer.parseInt(num);
      return true;
    }
    catch (NumberFormatException e) {
      return false;
  }
}

public void imageDraw(PImage img, String rat, float maxsize, PVector pos){
  switch(rat){
    case "1:1":
      image(img, pos.x, pos.y, maxsize, maxsize);
      imageSize.set(maxsize, maxsize);
      break;
    case "4:3":
      image(img, pos.x, pos.y, (maxsize/3)*4, maxsize);
      imageSize.set((maxsize/3)*4, maxsize);
      break;
    case "16:9":
      image(img, pos.x, pos.y, (maxsize/9)*16, maxsize);
      imageSize.set((maxsize/9)*16, maxsize);
      break;
  }
}

public void setGradient(float x, float y, float w, float h, int c1, int c2){
  for (float i = x; i <= x+w; i++) {
    stroke(lerpColor(c1, c2, map(i, x, x+w, 0, 1)));
    line(i, y, i, y+h);
  }
}

public void clock_r(int i){
  ZonedDateTime t = ZonedDateTime.now(zone[dsate][i]);
  s = map(t.getSecond(), 0, 60, 0, TWO_PI);
  s_sm = map(t.getSecond() + norm(t.getNano(), 0, 1000000000), 0, 60, 0, TWO_PI);
  m = map(t.getMinute(), 0, 60, 0, TWO_PI);
  m_sm = map(t.getMinute() + norm(t.getSecond(), 0, 60), 0, 60, 0, TWO_PI);
  h = map(t.getHour(), 0, 12, 0, HALF_PI);
  h_sm = map(t.getHour() + norm(t.getMinute(), 0, 60), 0, 12, 0, HALF_PI);
}

public void loading(){
  allscenevaule = "found "+config.length+" scenes";
  for(int i = 0; i < config.length; i++){
    //デフォルト値
    isloop[i] = false;
    mode[i] = config[i].getString("mode");
    //色
    if(config[i].getString("background").contains(",")){//RGBの場合
      String[] rgb = config[i].getString("background").split(",", 0);
      BGRGB[i] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
    }else{//白黒の場合
      BGRGB[i] = config[i].getInt("background");
    }
    switch(mode[i]){
      case "normal+":
        name[i] = config[i].getString("reference");
        plus = loadXML(name[i]);
        display = plus.getChildren("display");
        fade[i] = display.length-1;
        for(int o =0; o < display.length; o++){
          anyPos[i][o] = new PVector(width / 2, height / 2);
          name[i] = display[o].getString("name");
          if(name[i].contains(".png") || name[i].contains(".gif") || 
             name[i].contains(".jpg") || name[i].contains(".tga")){//画像
            time[i] = config[i].getInt("time");
            if(o == 0){
              image[i] = loadImage(mediadirectory+name[i]);
              if(image[i] == null){
                image[i] = createImage(100,100,ALPHA);
              }
              ratio[i] = display[o].getString("ratio");
              ftback[i] = ftpict;
            }else{
              backPlus[i][o] = loadImage(mediadirectory+name[i]);
              if(image[i] == null){
                image[i] = createImage(100,100,ALPHA);
              }
              ratioPlus[i][o] = display[o].getString("ratio");
              timing[i][o] = display[o].getInt("timing");
              duration[i][o] = display[o].getInt("duration");
              ftbackPlus[i][o] = ftpict;
            }
          }else 
          if(name[i].contains("hide")){//表示しない 
            if(o == 0){
              ftback[i] = fthide;
            }else{
              timing[i][o] = display[o].getInt("timing");
              duration[i][o] = display[o].getInt("duration");
              ftbackPlus[i][o] = fthide;
            }
          }
          if(display[o].hasChildren()){
            move = display[o].getChildren("move");
            for(int p =0; p < move.length; p++){
              movingEnd[i][o][p] = false;
              isMoving[i][o][p] = true;
              moveStart[i][o][p] = move[p].getFloat("startTime");
              moveDuration[i][o][p] = move[p].getFloat("duration");
              moveBehavior[i][o][p] = move[p].getString("behavior");
              String[] pos = move[p].getString("beginPos").split(",",0);
              moveBegin[i][o][p] = new PVector(PApplet.parseFloat(pos[0]), PApplet.parseFloat(pos[1])).add(centerPos);
              pos = move[p].getString("endPos").split(",", 0);
              moveEnd[i][o][p] = new PVector(PApplet.parseFloat(pos[0]), PApplet.parseFloat(pos[1])).add(centerPos);
              moveDist[i][o][p] = PVector.sub(moveEnd[i][o][p], moveBegin[i][o][p]);
            }
          }
        }
        break;
      case "normal":
        main_loading(i);
        break;
      case "debug":
        debug_screen = Settings.getInt("debug_screen");
        break;
      case "clock":
        main_loading(i);
        name[i] = config[i].getString("reference");
        time[i] = config[i].getInt("time");
        clock = loadXML(name[i]);
        try{
          object = clock.getChildren("object");
        }catch(NullPointerException e){
          nowload = "notfound:["+(i+1)+"]reference";
          return;
        }
        numOfClock[i] = object.length;
        for(int o = 0; o < numOfClock[i]; o++){
          String[] pos= {"",""};
          clockType[i][o] = object[o].getString("type");
          try{
            pos = object[o].getString("position").split(",", 0);
            clockPos[i][o] = new PVector(PApplet.parseFloat(pos[0]),PApplet.parseFloat(pos[1])).add(centerPos);
            stCloPos[i][o]=clockPos[i][o].copy();
          }catch(ArrayIndexOutOfBoundsException e){
            clockPos[i][o] = centerPos.copy();
          }
          try{
            clockSize[i][o] = object[o].getInt("size");
          }catch(NumberFormatException e){
            clockSize[i][o] = 100;
          }
          try{
            zone[i][o] = ZoneId.of(object[o].getString("zone"));
          }
          catch(RuntimeException e){
            zone[i][o] = ZoneId.systemDefault();
          }
          switch(clockType[i][o]){
            case "degital"://デジタル時計
              clockFont[i][o] = fontdirectory+object[o].getString("font");
              try{
                if(object[o].getString("color").contains(",")){//RGBの場合
                  String[] rgb = object[o].getString("color").split(",", 0);
                  fontColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
                }else{//白黒の場合
                  fontColor[i][o] = object[o].getInt("color");
                }
              }catch(NumberFormatException e){
                fontColor[i][o] = 0;
              }
              datetimeformat[i][o] = DateTimeFormatter.ofPattern(object[o].getString("pattern"));
              break;
            case "analog_img":
              /*盤部分*/
              boardImg[i][o] = loadImage(mediadirectory + object[o].getString("board"));
              if(boardImg[i][o] == null){
                boardImg[i][o] = createImage(100,100,ALPHA);
              }
              String[] offset = {"",""};
              /*秒針部分*/
              xmlSec = object[o].getChild("sec");
              secImg[i][o] = loadImage(mediadirectory + xmlSec.getString("name"));
              if(secImg[i][o] == null){
                secImg[i][o] = createImage(100,100,ALPHA);
              }
              try{
                offset = xmlSec.getString("offset").split(",", 0);
                secAxis[i][o] = new PVector(PApplet.parseFloat(offset[0]),PApplet.parseFloat(offset[1]));
              }catch(ArrayIndexOutOfBoundsException e){
                secAxis[i][o] = new PVector(0,0);
              }
              if(xmlSec.getString("smooth") == null){
                secSmooth[i][o] = false;
              }else if(xmlSec.getString("smooth").contains("true")){
                secSmooth[i][o] = true;
              }else{
                secSmooth[i][o] = false;
              }
              /*長針部分*/
              xmlMin = object[o].getChild("min");
              minImg[i][o] = loadImage(mediadirectory + xmlMin.getString("name"));
              if(minImg[i][o] == null){
                minImg[i][o] = createImage(100,100,ALPHA);
              }
              try{
                offset = xmlMin.getString("offset").split(",", 0);
                minAxis[i][o] = new PVector(PApplet.parseFloat(offset[0]),PApplet.parseFloat(offset[1]));
              }catch(ArrayIndexOutOfBoundsException e){
                minAxis[i][o] = new PVector(0,0);
              }
              if(xmlMin.getString("smooth") == null){
                minSmooth[i][o] = false;
              }else if(xmlMin.getString("smooth").contains("true")){
                minSmooth[i][o] = true;
              }else{
                minSmooth[i][o] = false;
              }
              /*短針部分*/
              xmlHour = object[o].getChild("hour");
              hourImg[i][o] = loadImage(mediadirectory + xmlHour.getString("name"));
              if(hourImg[i][o] == null){
                hourImg[i][o] = createImage(100,100,ALPHA);
              }
              try{
                offset = xmlHour.getString("offset").split(",",0);
                hourAxis[i][o] = new PVector(PApplet.parseFloat(offset[0]),PApplet.parseFloat(offset[1]));
              }catch(ArrayIndexOutOfBoundsException e){
                hourAxis[i][o] = new PVector(0,0);
              }
              if(xmlHour.getString("smooth") == null){
                hourSmooth[i][o] = false;
              }else if(xmlHour.getString("smooth").contains("true")){
                hourSmooth[i][o] = true;
              }else{
                hourSmooth[i][o] = false;
              }
              /*基準サイズ定義*/
              clockSize[i][o] = (clockSize[i][o]/100)*(height/2);
              secondsRadius[i][o] = clockSize[i][o] * 0.72f;
              minutesRadius[i][o] = clockSize[i][o] * 0.65f;
              hoursRadius[i][o] = clockSize[i][o] * 0.50f;
              clockDiameter[i][o] = clockSize[i][o] * 1.8f;
              break;
            case "analog_pro":
              /*盤部分*/
              xmlboard = object[o].getChild("board");
              if(xmlboard.getString("dialColor").contains(",")){//RGBの場合
                String[] rgb = xmlboard.getString("dialColor").split(",", 0);
                dialColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
              }else{//白黒の場合
                dialColor[i][o] = xmlboard.getInt("dialColor");
              }
              if(xmlboard.getString("indexColor").contains(",")){//RGBの場合
                String[] rgb = xmlboard.getString("indexColor").split(",", 0);
                indexColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
              }else{//白黒の場合
                indexColor[i][o] = xmlboard.getInt("indexColor");
              }
              indexwidth[i][o] = xmlboard.getInt("indexwidth");
              /*秒針部分*/
              xmlSec = object[o].getChild("sec");
              if(xmlSec.getString("color").contains(",")){//RGBの場合
                String[] rgb = xmlSec.getString("color").split(",", 0);
                secColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
              }else{//白黒の場合
                secColor[i][o] = xmlSec.getInt("color");
              }
              secWidth[i][o] = xmlSec.getInt("width");
              if(xmlSec.getString("smooth") == null){
                secSmooth[i][o] = false;
              }else if(xmlSec.getString("smooth").contains("true")){
                secSmooth[i][o] = true;
              }else{
                secSmooth[i][o] = false;
              }
              /*長針部分*/
              xmlMin = object[o].getChild("min");
              if(xmlMin.getString("color").contains(",")){//RGBの場合
                String[] rgb = xmlMin.getString("color").split(",", 0);
                minColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
              }else{//白黒の場合
                minColor[i][o] = xmlMin.getInt("color");
              }
              minWidth[i][o] = xmlMin.getInt("width");
              if(xmlMin.getString("smooth") == null){
                minSmooth[i][o] = false;
              }else if(xmlMin.getString("smooth").contains("true")){
                minSmooth[i][o] = true;
              }else{
                minSmooth[i][o] = false;
              }
              /*短針部分*/
              xmlHour = object[o].getChild("hour");
              if(xmlHour.getString("color").contains(",")){//RGBの場合
                String[] rgb = xmlHour.getString("color").split(",", 0);
                hourColor[i][o] = color(PApplet.parseInt(rgb[0]),PApplet.parseInt(rgb[1]),PApplet.parseInt(rgb[2]));
              }else{//白黒の場合
                hourColor[i][o] = xmlHour.getInt("color");
              }
              hourWidth[i][o] = xmlHour.getInt("width");
              if(xmlHour.getString("smooth") == null){
                hourSmooth[i][o] = false;
              }else if(xmlHour.getString("smooth").contains("true")){
                hourSmooth[i][o] = true;
              }else{
                hourSmooth[i][o] = false;
              }
              /*基準サイズ定義*/
              clockSize[i][o] = (clockSize[i][o]/100)*(height/2);
              secondsRadius[i][o] = clockSize[i][o] * secHandsize;
              minutesRadius[i][o] = clockSize[i][o] * minHandsize;
              hoursRadius[i][o] = clockSize[i][o] * hourHandsize;
              dialRadius[i][o] = clockSize[i][o] * indexOut;
              dialRadius2[i][o] = clockSize[i][o] * indexIn;
              dialRadius3[i][o] = clockSize[i][o] * indexIn_2;
              clockDiameter[i][o] = clockSize[i][o] * dialsize;
              break;
            default:
             break;
          }
          String[] list = object[o].listChildren();
          if(Arrays.asList(list).contains("move")){
            move = object[o].getChildren("move");
            for(int p =0; p < move.length; p++){
              movingEnd[i][o][p] = false;
              isMoving[i][o][p] = true;
              moveStart[i][o][p] = move[p].getFloat("startTime");
              moveDuration[i][o][p] = move[p].getFloat("duration");
              moveBehavior[i][o][p] = move[p].getString("behavior");
              pos = move[p].getString("beginPos").split(",",0);
              moveBegin[i][o][p] = new PVector(PApplet.parseFloat(pos[0]), PApplet.parseFloat(pos[1])).add(centerPos);
              pos = move[p].getString("endPos").split(",", 0);
              moveEnd[i][o][p] = new PVector(PApplet.parseFloat(pos[0]), PApplet.parseFloat(pos[1])).add(centerPos);
              moveDist[i][o][p] = PVector.sub(moveEnd[i][o][p], moveBegin[i][o][p]);
            }
          }
        }
        break;
      default:
        break;
    }
    print(i+1+"\n");
    nowload = "now "+(i+1)+" loading...";
  }
  print("Total loading time "+millis()+" [ms]\n");
  nowload = "loading all done!";
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "TTSP_1_5_1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
